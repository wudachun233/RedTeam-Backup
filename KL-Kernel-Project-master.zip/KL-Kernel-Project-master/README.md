# KL-Kernel-Project
Kernel Driver for intercepting key strokes.

I am not responsible for any damages of any kind due to the misuse of this code.

